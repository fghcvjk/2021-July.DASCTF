INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'layout_member_body_foot', '会员中心模板底部接口', 1, 0);
INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'layout_member_body_head', '会员中心模板头部接口', 1, 0);
