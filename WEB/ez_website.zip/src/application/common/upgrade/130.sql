ALTER TABLE  `qb_memberdata` ADD  `weixin_yz` TINYINT( 1 ) NOT NULL COMMENT  '微信人脸实名验证' AFTER  `idcard_yz` ;
