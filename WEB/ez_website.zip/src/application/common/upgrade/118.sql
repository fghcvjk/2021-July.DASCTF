UPDATE `qb_chatmod` SET `status`=0 WHERE `keywords`='p2pvideo';
