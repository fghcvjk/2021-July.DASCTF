ALTER TABLE  `qb_attachment` ADD INDEX (  `uid` );
ALTER TABLE  `qb_attachment` ADD INDEX (  `md5` );
ALTER TABLE  `qb_memberdata` COMMENT =  '用户数据表';
