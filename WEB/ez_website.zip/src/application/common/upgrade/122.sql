ALTER TABLE  `qb_redis_index` CHANGE  `v`  `v` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT  'value值';
ALTER TABLE  `qb_redis_list` CHANGE  `v`  `v` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT  'value值';
