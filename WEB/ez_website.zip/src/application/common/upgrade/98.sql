ALTER TABLE `qb_labelhy` DROP INDEX  `page` ,ADD INDEX (  `pagename` ,  `ext_id` ,  `fid` );
