ALTER TABLE  `qb_rmb_consume` ADD  `freeze_money` DECIMAL( 10, 2 ) NOT NULL COMMENT  '不可用余额变动';
