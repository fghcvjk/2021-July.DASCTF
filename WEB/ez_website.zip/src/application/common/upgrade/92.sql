INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'add_msg_begin', '短消息(群聊)发布接口(入库前)', 1, 0);
INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'add_msg_end', '短消息(群聊)发布接口(入库后)', 1, 0);
