<?php
namespace app\common\controller\member;

use app\common\controller\memberBase;

abstract class S extends memberBase
{
    
}